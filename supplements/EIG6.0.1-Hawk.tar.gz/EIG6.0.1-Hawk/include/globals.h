#ifndef _GLOBALS_
#define _GLOBALS_

int numchrom = 22;
int fancynorm=YES, verbose=NO, plotmode=NO, outnum = -1 ;

#endif

