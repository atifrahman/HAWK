import warnings

warnings.warn("Module 'jellyfish' is deprecated. Use 'dna_jellyfish'", DeprecationWarning)
import dna_jellyfish as jellyfish
